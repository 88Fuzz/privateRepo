Bloodsuckers 1.1 (TrueType for Windows)...

...was hacked into existence by copying the title of a gruesome 50's cheapo horror comic and mad-doctoring the letters that
AREN'T in the words, "BLOOD-SUCKERS" into being.

This font is freeware, but copyrighted (C) 1997 Letters From The Claw.
Distribute it freely.  Widely.  Promiscuously.

All numbers and some punctuation are included, as well as five dingbat images:

Shift-6 - ^ ... 3 skulls
left paren - ( ... a ghoul
right paren - ) ... a zombie
bar - | ... a severed head
"At" sign - @ ... a bloody hand pointing right 
(Makes really cool "email addresses")

Bloodsuckers (the font) shouldn't do anything to harm your computer, but if it does, (EEYIKES!) I'm not responsible.  You're on your own.

For more fabulous fonts, including DEVO (based on The Supreme Spuds' logo and featuring DEVO-dingbats), visit The Empire Of The Claw:

http://www.empireoftheclaw.com

Enjoy the font!

The Claw
theclaw@empireoftheclaw.com
